from odoo import _, api, fields, models
from odoo.exceptions import UserError


_PHONE_TOKENS = (
    "mobile", "phone", "whatsapp", "whats_app", "telephone", "tel",
    "Mobile", "Phone", "WhatsApp",
)
_RELATION_HINTS = (
    "partner", "customer", "client", "contact", "commercial_partner",
    "Client", "Contact",
)


class WatiAutomationRecipient(models.Model):
    _inherit = "wati.automation.rule"

    recipient_mode = fields.Selection(
        [
            ("auto", "Automatic — Recommended"),
            ("direct", "Phone from this record"),
            ("related", "Phone from a related record"),
        ],
        string="Recipient source",
        default="auto",
        copy=True,
    )
    recipient_advanced_path = fields.Char(
        string="Custom number path",
        copy=True,
        help="For advanced use only. Example: partner_id.mobile",
    )
    smart_recipient_metadata = fields.Json(
        string="Smart recipient options",
        compute="_compute_smart_recipient_state",
    )
    recipient_summary = fields.Char(
        string="Recipient",
        compute="_compute_smart_recipient_state",
    )
    recipient_preview_note = fields.Char(
        string="Preview recipient",
        compute="_compute_smart_recipient_state",
    )

    @api.model
    def _is_phone_like_field(self, field):
        if getattr(field, "type", "") not in ("char", "text"):
            return False
        haystack = f"{getattr(field, 'name', '')} {getattr(field, 'string', '')}".casefold()
        return any(token.casefold() in haystack for token in _PHONE_TOKENS)

    @api.model
    def _phone_field_score(self, field):
        name = (getattr(field, "name", "") or "").casefold()
        if name == "mobile":
            return 0
        if name == "phone":
            return 1
        if "whatsapp" in name:
            return 2
        if "mobile" in name:
            return 3
        if "phone" in name:
            return 4
        return 8

    @api.model
    def _relation_score(self, field):
        haystack = f"{getattr(field, 'name', '')} {getattr(field, 'string', '')}".casefold()
        return 0 if any(token.casefold() in haystack for token in _RELATION_HINTS) else 5

    @api.model
    def _mask_phone_for_preview(self, phone):
        digits = "".join(ch for ch in str(phone or "") if ch.isdigit())
        if not digits:
            return ""
        if len(digits) <= 4:
            return digits
        if len(digits) <= 7:
            return f"{digits[:2]}{'•' * (len(digits) - 4)}{digits[-2:]}"
        return f"{digits[:4]}{'•' * max(4, len(digits) - 7)}{digits[-3:]}"

    def _recipient_preview_resolution(self, path):
        """Resolve a configured recipient path against recent real records.

        The preview intentionally masks the number and never changes business data.
        We scan a small set of recent records so the builder can prove that a path
        such as partner_id.phone is not only syntactically valid but actually
        resolves to a usable number in live Odoo data.
        """
        self.ensure_one()
        model_name = self.model_id.model if self.model_id else False
        path = (path or "").strip()
        if not model_name or model_name not in self.env or not path:
            return "", ""

        try:
            records = self.env[model_name].sudo().search([], order="id desc", limit=20)
        except Exception:
            return "", ""

        for record in records:
            try:
                raw = self._resolve_path(record, path)
                normalized = self._normalize_phone(raw) if raw else ""
            except Exception:
                continue
            if not normalized:
                continue
            label = record.display_name or f"{model_name},{record.id}"
            return self._mask_phone_for_preview(normalized), label
        return "", ""

    def _recipient_path_options(self, max_depth=2, limit=80):
        """Discover useful phone paths from the selected Odoo model.

        This deliberately reads Odoo model metadata instead of hard-coding CRM,
        Helpdesk, Sales, Project, or custom app names.
        """
        self.ensure_one()
        model_name = self.model_id.model if self.model_id else False
        if not model_name or model_name not in self.env:
            return []

        options = []
        seen_paths = set()

        def add_option(path, label, depth, score):
            if not path or path in seen_paths or len(options) >= limit:
                return
            seen_paths.add(path)
            options.append({
                "value": path,
                "label": label,
                "depth": depth,
                "score": score,
            })

        def walk(current_model_name, prefix="", label_prefix="", depth=0, visited=None):
            if len(options) >= limit or current_model_name not in self.env:
                return
            visited = set(visited or set())
            if current_model_name in visited and depth:
                return
            visited.add(current_model_name)
            Model = self.env[current_model_name]

            phone_fields = [
                field for field in Model._fields.values()
                if self._is_phone_like_field(field)
            ]
            phone_fields.sort(key=self._phone_field_score)
            for field in phone_fields:
                field_label = getattr(field, "string", False) or field.name
                path = f"{prefix}.{field.name}" if prefix else field.name
                label = f"{label_prefix} → {field_label}" if label_prefix else field_label
                add_option(path, label, depth, depth * 20 + self._phone_field_score(field))

            if depth >= max_depth:
                return

            relations = [
                field for field in Model._fields.values()
                if getattr(field, "type", "") == "many2one"
                and getattr(field, "comodel_name", False)
                and field.name not in ("create_uid", "write_uid")
            ]
            relations.sort(key=self._relation_score)
            for field in relations:
                relation = field.comodel_name
                if relation not in self.env:
                    continue
                relation_label = getattr(field, "string", False) or field.name
                path_prefix = f"{prefix}.{field.name}" if prefix else field.name
                next_label = f"{label_prefix} → {relation_label}" if label_prefix else relation_label
                walk(relation, path_prefix, next_label, depth + 1, visited)

        walk(model_name)
        return sorted(options, key=lambda item: (item["score"], item["label"].casefold()))[:limit]

    @api.depends(
        "model_id", "recipient_mode", "recipient_path", "recipient_field_id",
        "recipient_advanced_path",
    )
    def _compute_smart_recipient_state(self):
        for rule in self:
            mode = rule.recipient_mode or "auto"
            options = rule._recipient_path_options() if rule.model_id else []
            direct = [item for item in options if item["depth"] == 0]
            related = [item for item in options if item["depth"] > 0]
            visible = direct if mode == "direct" else related if mode == "related" else options

            rule.smart_recipient_metadata = {
                "mode": "select" if visible else "empty",
                "placeholder": (
                    "Select a phone field from this record"
                    if mode == "direct"
                    else "Select a phone field from a related record"
                ),
                "options": [
                    {"value": item["value"], "label": item["label"]}
                    for item in visible
                ],
            }

            selected = next(
                (item for item in options if item["value"] == (rule.recipient_path or "")),
                None,
            )
            if rule.recipient_advanced_path:
                masked, record_label = rule._recipient_preview_resolution(rule.recipient_advanced_path)
                rule.recipient_summary = _("Custom number path")
                if masked:
                    rule.recipient_preview_note = _(
                        "Resolved from %(record)s: %(number)s"
                    ) % {"record": record_label, "number": masked}
                else:
                    rule.recipient_preview_note = _(
                        "The advanced path is configured, but no recent record resolved to a usable phone number."
                    )
            elif mode == "auto":
                rule.recipient_summary = _("Customer number automatically")
                resolved = ""
                resolved_label = ""
                resolved_path_label = ""
                for item in options[:12]:
                    masked, record_label = rule._recipient_preview_resolution(item["value"])
                    if masked:
                        resolved = masked
                        resolved_label = record_label
                        resolved_path_label = item["label"]
                        break
                if resolved:
                    rule.recipient_preview_note = _(
                        "Resolved automatically from %(path)s on %(record)s: %(number)s"
                    ) % {
                        "path": resolved_path_label,
                        "record": resolved_label,
                        "number": resolved,
                    }
                elif options:
                    labels = ", ".join(item["label"] for item in options[:3])
                    rule.recipient_preview_note = _(
                        "The system will automatically search in the most appropriate order, e.g: %s",
                        labels,
                    )
                else:
                    rule.recipient_preview_note = _(
                        "We haven’t found a clear phone field yet; You can choose an advanced path if necessary."
                    )
            elif selected:
                masked, record_label = rule._recipient_preview_resolution(selected["value"])
                rule.recipient_summary = selected["label"]
                if masked:
                    rule.recipient_preview_note = _(
                        "Resolved from %(record)s via %(path)s: %(number)s"
                    ) % {
                        "record": record_label,
                        "path": selected["label"],
                        "number": masked,
                    }
                else:
                    rule.recipient_preview_note = _(
                        "Path %(path)s is selected, but no recent record currently resolves to a usable phone number."
                    ) % {"path": selected["label"]}
            else:
                rule.recipient_summary = _("Choose the recipient number")
                rule.recipient_preview_note = (
                    _("Choose a phone field from the same record.")
                    if mode == "direct"
                    else _("Choose a phone field from a linked record.")
                )

    @api.onchange("recipient_mode")
    def _onchange_recipient_mode(self):
        for rule in self:
            rule.recipient_path = False
            rule.recipient_field_id = False

    @api.onchange("recipient_path")
    def _onchange_smart_recipient_path(self):
        for rule in self:
            if (rule.recipient_mode or "auto") == "direct" and rule.model_id and rule.recipient_path:
                field = self.env["ir.model.fields"].sudo().search([
                    ("model_id", "=", rule.model_id.id),
                    ("name", "=", rule.recipient_path),
                ], limit=1)
                rule.recipient_field_id = field
            elif (rule.recipient_mode or "auto") == "related":
                rule.recipient_field_id = False

    def _recipient_phone(self, record):
        self.ensure_one()
        advanced = (self.recipient_advanced_path or "").strip()
        if advanced:
            value = self._resolve_path(record, advanced)
            return self._normalize_phone(value) if value else ""

        mode = self.recipient_mode or "auto"
        if mode in ("direct", "related"):
            path = (self.recipient_path or "").strip()
            if not path:
                return ""
            value = self._resolve_path(record, path)
            return self._normalize_phone(value) if value else ""

        # Preserve pre-existing rules that already have an explicit recipient.
        if self.recipient_path or self.recipient_field_id:
            return super()._recipient_phone(record)

        for option in self._recipient_path_options():
            value = self._resolve_path(record, option["value"])
            if value:
                normalized = self._normalize_phone(value)
                if normalized:
                    return normalized
        return super()._recipient_phone(record)

    def _validate_step(self, step=None):
        result = super()._validate_step(step)
        step = step or self.setup_step
        if step == "recipient":
            mode = self.recipient_mode or "auto"
            if mode in ("direct", "related") and not (self.recipient_path or "").strip():
                raise UserError(_("Choose the recipient’s number before continuing."))
        return result

    @api.depends(
        "recipient_mode", "recipient_path", "recipient_field_id", "recipient_advanced_path"
    )
    def _compute_ux_state(self):
        super()._compute_ux_state()
        for rule in self:
            if not rule.human_summary:
                continue
            if rule.recipient_field_id:
                old_recipient = rule.recipient_field_id.field_description or rule.recipient_field_id.name
            elif rule.recipient_path:
                old_recipient = rule.recipient_path
            else:
                old_recipient = "Customer number automatically"
            if rule.recipient_summary:
                rule.human_summary = rule.human_summary.replace(
                    f"To {old_recipient}", f"To {rule.recipient_summary}", 1
                )

            if (rule.recipient_mode or "auto") == "auto" and rule._recipient_path_options():
                lines = [
                    line for line in (rule.readiness_message or "").splitlines()
                    if "The system will automatically search for mobile / phone / Associated customer number" not in line
                ]
                rule.readiness_message = "\n".join(lines)
                if rule.readiness_state == "warning" and not any(line.startswith("⚠️") for line in lines):
                    rule.readiness_state = "ready"
