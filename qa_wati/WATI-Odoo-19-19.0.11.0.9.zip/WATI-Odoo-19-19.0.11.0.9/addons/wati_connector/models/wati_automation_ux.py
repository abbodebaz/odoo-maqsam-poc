import re

from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError

from ..services.client import WatiClient
from ..services.config import WatiConfig
from ..services.exceptions import WatiRequestError
from .wati_automation_improvements import (
    _find_template_list,
    _template_body,
    _template_name,
    _template_param_names,
)


_OPERATOR_LABELS = {
    "eq": "equals",
    "ne": "Not equal",
    "contains": "Contains",
    "gt": "Greater than",
    "gte": "Greater than or equal to",
    "lt": "less than",
    "lte": "Less than or equal to",
    "is_set": "It has value",
    "is_not_set": "Without value",
}
_GENERAL_TEMPLATE_NAMES = {"whatsapp", "wati", "unknown", "none", "null"}


class WatiAutomationRuleUX(models.Model):
    _inherit = "wati.automation.rule"

    active = fields.Boolean(default=False)
    template_name = fields.Char(string="WATI Template", required=False)
    setup_step = fields.Selection(
        [
            ("trigger", "1. When?"),
            ("recipient", "2. for whom?"),
            ("message", "3. The message"),
            ("review", "4. Review"),
        ],
        string="Setup step",
        default="trigger",
        required=True,
        copy=False,
    )
    preset_key = fields.Selection(
        selection="_wati_preset_selection",
        string="Start from a ready setting",
        copy=False,
    )
    human_summary = fields.Char(string="Rule summary", compute="_compute_ux_state")
    readiness_state = fields.Selection(
        [("ready", "Ready"), ("warning", "Need review"), ("incomplete", "Incomplete")],
        string="Readiness",
        compute="_compute_ux_state",
    )
    readiness_message = fields.Text(string="Readiness check", compute="_compute_ux_state")
    template_body = fields.Text(string="Template text", readonly=True, copy=False)
    preview_text = fields.Text(string="Preview the message", readonly=True, copy=False)
    preview_record_name = fields.Char(string="Preview record", readonly=True, copy=False)
    test_phone = fields.Char(string="Test number", copy=False, help="The customer number will not be used when sending the test.")

    @api.model
    def _wati_preset_definitions(self):
        """Extension hook for optional business-app addons.

        The core connector intentionally knows nothing about CRM, Sales,
        Accounting, Project, Helpdesk, or Field Service. Integration addons
        extend this mapping when they are installed.
        """
        return {}

    @api.model
    def _wati_preset_selection(self):
        definitions = self._wati_preset_definitions()
        return [(key, value["label"]) for key, value in definitions.items()]

    @api.depends(
        "name", "model_id", "trigger_field_id", "condition_operator", "target_value",
        "recipient_field_id", "recipient_path", "template_name", "once_per_record",
        "parameter_ids.param_name", "parameter_ids.source_type", "parameter_ids.source_field_id",
        "parameter_ids.source_path", "parameter_ids.static_value",
    )
    def _compute_ux_state(self):
        api_ready = WatiConfig(self.env).is_api_configured
        for rule in self:
            model_label = rule.model_id.name or "Application"
            field_label = rule.trigger_field_id.field_description or rule.trigger_field_id.name or "field"
            operator = _OPERATOR_LABELS.get(rule.condition_operator, rule.condition_operator or "")
            target = (rule.target_value or "").strip()
            if rule.condition_operator in ("is_set", "is_not_set"):
                condition_text = f"{field_label} {operator}"
            elif target:
                condition_text = f"{field_label} {operator} «{target}»"
            else:
                condition_text = f"{field_label} {operator} ..."

            if rule.recipient_field_id:
                recipient = rule.recipient_field_id.field_description or rule.recipient_field_id.name
            elif rule.recipient_path:
                recipient = rule.recipient_path
            else:
                recipient = "Customer number automatically"

            template = rule.template_name or "Template not yet defined"
            once = " · Once per record" if rule.once_per_record else ""
            rule.human_summary = f"When {condition_text} In {model_label} ← Send «{template}» To {recipient}{once}"

            errors = []
            warnings = []
            if not rule.name:
                errors.append("Rule name")
            if not rule.model_id:
                errors.append("Application / Model")
            if not rule.trigger_field_id:
                errors.append("Monitored field")
            if rule.condition_operator not in ("is_set", "is_not_set") and not target:
                errors.append("Required value")
            if not rule.template_name:
                errors.append("Template WATI")
            if not api_ready:
                errors.append("Contact WATI API")

            unmapped = []
            for line in rule.parameter_ids:
                if not line.param_name:
                    continue
                mapped = (
                    line.source_type in ("record_id", "record_name")
                    or (line.source_type == "static" and bool((line.static_value or "").strip()))
                    or (
                        line.source_type == "field"
                        and bool(line.source_field_id or (line.source_path or "").strip())
                    )
                )
                if not mapped:
                    unmapped.append(line.param_name)
            if unmapped:
                errors.append("Unbound variables: " + ", ".join(unmapped[:6]))
            if rule.template_name and not rule.parameter_ids:
                warnings.append("Template variables have not been fetched yet; If the template contains variables, click Get Variables.")
            if not rule.recipient_field_id and not rule.recipient_path:
                warnings.append("The system will automatically search for mobile / phone / Associated customer number.")

            rule.readiness_state = "incomplete" if errors else ("warning" if warnings else "ready")
            checklist = [
                "✅ Application and event specific" if rule.model_id and rule.trigger_field_id else "❌ Select the application and the monitored field",
                "✅ The condition is complete" if (rule.condition_operator in ("is_set", "is_not_set") or target) else "❌ Select the desired value",
                "✅ Template WATI Specific" if rule.template_name else "❌ Choose a template WATI",
                "✅ Contact WATI Ready" if api_ready else "❌ Settings WATI API Incomplete",
            ]
            if unmapped:
                checklist.append("❌ Fasten: " + ", ".join(unmapped[:6]))
            elif rule.parameter_ids:
                checklist.append(f"✅ {len(rule.parameter_ids)} Bound variables")
            elif rule.template_name:
                checklist.append("⚠️ There are no variables loaded for the template")
            checklist.extend("⚠️ " + item for item in warnings)
            rule.readiness_message = "\n".join(checklist)

    def _validate_step(self, step=None):
        self.ensure_one()
        step = step or self.setup_step
        if step == "trigger":
            missing = []
            if not self.name:
                missing.append("Rule name")
            if not self.model_id:
                missing.append("Application")
            if not self.trigger_field_id:
                missing.append("Monitored field")
            if self.condition_operator not in ("is_set", "is_not_set") and not (self.target_value or "").strip():
                missing.append("Required value")
            if missing:
                raise UserError(_("Complete the first step: %s", ", ".join(missing)))
        elif step == "message" and not self.template_name:
            raise UserError(_("Choose a template WATI First."))

    def _validate_activation(self):
        self.ensure_one()
        self._compute_ux_state()
        if self.readiness_state == "incomplete":
            raise ValidationError(_("The rule is not ready to be activated:\n%s", self.readiness_message))

    def action_next_step(self):
        self.ensure_one()
        self._validate_step(self.setup_step)
        order = ["trigger", "recipient", "message", "review"]
        index = order.index(self.setup_step)
        if index < len(order) - 1:
            self.setup_step = order[index + 1]
        return {"type": "ir.actions.client", "tag": "soft_reload"}

    def action_previous_step(self):
        self.ensure_one()
        order = ["trigger", "recipient", "message", "review"]
        index = order.index(self.setup_step)
        if index > 0:
            self.setup_step = order[index - 1]
        return {"type": "ir.actions.client", "tag": "soft_reload"}

    def action_activate_rule(self):
        self.ensure_one()
        self._validate_activation()
        self.write({"active": True, "setup_step": "review"})
        self._sync_odoo_automation()
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("Automation has been activated"),
                "message": self.human_summary,
                "type": "success",
                "sticky": False,
                "next": {"type": "ir.actions.client", "tag": "soft_reload"},
            },
        }

    def action_deactivate_rule(self):
        self.ensure_one()
        self.write({"active": False})
        return {"type": "ir.actions.client", "tag": "soft_reload"}

    def write(self, vals):
        result = super().write(vals)
        if vals.get("active") is True:
            for rule in self:
                rule._validate_activation()
        return result

    def action_duplicate_rule(self):
        self.ensure_one()
        duplicate = self.copy(default={
            "name": _("%s — Copy", self.name),
            "active": False,
            "setup_step": "trigger",
            "base_automation_id": False,
            "server_action_id": False,
            "preview_text": False,
            "preview_record_name": False,
            "test_phone": False,
        })
        return {
            "type": "ir.actions.act_window",
            "name": _("A copy of the rule"),
            "res_model": "wati.automation.rule",
            "res_id": duplicate.id,
            "view_mode": "form",
            "target": "current",
        }

    def action_apply_preset(self):
        self.ensure_one()
        definition = self._wati_preset_definitions().get(self.preset_key)
        if not definition:
            raise UserError(_("Choose a ready setting first."))

        model_name = definition["model"]
        field_name = definition["field"]
        target = definition["target"]
        recipient_fields = tuple(definition.get("recipient_fields", ()))
        recipient_path = definition.get("recipient_path") or False
        default_name = definition["name"]

        model = self.env["ir.model"].sudo().search([("model", "=", model_name)], limit=1)
        if not model:
            raise UserError(_("The requested application is not currently installed in Odoo: %s", model_name))
        trigger = self.env["ir.model.fields"].sudo().search(
            [("model_id", "=", model.id), ("name", "=", field_name)],
            limit=1,
        )
        if not trigger:
            raise UserError(_("I couldn’t find the field %s In the chosen application.", field_name))

        recipient = False
        for field in recipient_fields:
            recipient = self.env["ir.model.fields"].sudo().search(
                [("model_id", "=", model.id), ("name", "=", field)],
                limit=1,
            )
            if recipient:
                break

        self.write({
            "name": self.name or default_name,
            "model_id": model.id,
            "trigger_field_id": trigger.id,
            "condition_operator": definition.get("operator", "eq"),
            "target_value": target,
            "recipient_field_id": recipient.id if recipient else False,
            "recipient_path": False if recipient else recipient_path,
            "once_per_record": definition.get("once_per_record", True),
            "setup_step": "trigger",
        })
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("The ready setting has been applied"),
                "message": self.human_summary,
                "type": "success",
                "sticky": False,
                "next": {"type": "ir.actions.client", "tag": "soft_reload"},
            },
        }

    def _target_choices(self):
        self.ensure_one()
        if not self.model_id or not self.trigger_field_id:
            return []
        Model = self.env.get(self.model_name)
        if not Model or self.trigger_field_id.name not in Model._fields:
            return []
        field = Model._fields[self.trigger_field_id.name]
        if field.type == "selection":
            try:
                return [(str(value), str(label)) for value, label in field._description_selection(self.env)]
            except Exception:
                return []
        if field.type == "many2one":
            try:
                records = self.env[field.comodel_name].sudo().search([], limit=150)
                return [(str(record.id), record.display_name or str(record.id)) for record in records]
            except Exception:
                return []
        if field.type == "boolean":
            return [("True", _("Yes")), ("False", _("No"))]
        return []

    def action_pick_target_value(self):
        self.ensure_one()
        choices = self._target_choices()
        if not choices:
            raise UserError(_("This field does not contain a ready-made list of values; Type the required value manually."))
        Choice = self.env["wati.automation.value.choice"]
        Choice.search([("rule_id", "=", self.id)]).unlink()
        Choice.create([{"rule_id": self.id, "value": value, "label": label} for value, label in choices])
        return {
            "type": "ir.actions.act_window",
            "name": _("Choose the desired value"),
            "res_model": "wati.automation.value.choice",
            "view_mode": "list",
            "views": [(self.env.ref("wati_connector.view_wati_automation_value_choice_list").id, "list")],
            "domain": [("rule_id", "=", self.id)],
            "target": "new",
        }

    def _fetch_wati_templates(self):
        self.ensure_one()
        try:
            response = WatiClient(self.env).get_message_templates(page_size=200, page_number=1)
        except WatiRequestError as exc:
            raise UserError(_("Unable to fetch templates WATI: %s", exc)) from exc
        try:
            return _find_template_list(response.json())
        except ValueError as exc:
            raise UserError(_("WATI Returned an unintelligible response when fetching templates.")) from exc

    def action_pick_template(self):
        self.ensure_one()
        templates = self._fetch_wati_templates()
        if not templates:
            raise UserError(_("No templates found WhatsApp In an account WATI."))
        Choice = self.env["wati.automation.template.choice"]
        Choice.search([("rule_id", "=", self.id)]).unlink()
        values = []
        for item in templates:
            name = _template_name(item)
            if not name or name.casefold() in _GENERAL_TEMPLATE_NAMES:
                continue
            status = str(item.get("status") or item.get("approvalStatus") or item.get("templateStatus") or "") if isinstance(item, dict) else ""
            category = str(item.get("category") or item.get("type") or "") if isinstance(item, dict) else ""
            values.append({
                "rule_id": self.id,
                "name": name,
                "status": status,
                "category": category,
                "body": _template_body(item),
            })
        if values:
            Choice.create(values)
        return {
            "type": "ir.actions.act_window",
            "name": _("Choose a template WATI"),
            "res_model": "wati.automation.template.choice",
            "view_mode": "list",
            "views": [(self.env.ref("wati_connector.view_wati_automation_template_choice_list").id, "list")],
            "domain": [("rule_id", "=", self.id)],
            "target": "new",
        }

    def _auto_map_parameters(self):
        self.ensure_one()
        if not self.model_id:
            return 0
        Fields = self.env["ir.model.fields"].sudo()
        model_fields = Fields.search([("model_id", "=", self.model_id.id)])
        by_name = {field.name.casefold(): field for field in model_fields}
        mapped = 0
        for line in self.parameter_ids:
            if line.source_type != "field" or line.source_field_id or (line.source_path or "").strip():
                continue
            key = re.sub(r"[^a-z0-9]+", "_", (line.param_name or "").casefold()).strip("_")
            target_field = by_name.get(key)
            vals = {}
            if target_field:
                vals["source_field_id"] = target_field.id
            elif any(token in key for token in ("client", "customer", "contact")) and "partner_id" in by_name:
                vals["source_path"] = "partner_id.name"
            elif key in ("id", "record_id") or key.endswith("_id2") or key.endswith("_id"):
                vals["source_type"] = "record_id"
            elif any(token in key for token in ("dep", "department", "team")) and "team_id" in by_name:
                vals["source_path"] = "team_id.name"
            elif any(token in key for token in ("name", "title", "sap")) and "name" in by_name:
                vals["source_field_id"] = by_name["name"].id
            if vals:
                line.write(vals)
                mapped += 1
        return mapped

    def action_auto_map_parameters(self):
        self.ensure_one()
        mapped = self._auto_map_parameters()
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("Smart connectivity"),
                "message": _("has been linked %s Automatically variable. Review the rest before activation.", mapped),
                "type": "success" if mapped else "warning",
                "sticky": False,
                "next": {"type": "ir.actions.client", "tag": "soft_reload"},
            },
        }

    def action_fetch_template_params(self):
        result = super().action_fetch_template_params()
        try:
            wanted = (self.template_name or "").strip().casefold()
            template = next(
                (item for item in self._fetch_wati_templates() if _template_name(item).casefold() == wanted),
                None,
            )
            if template:
                self.template_body = _template_body(template)
        except Exception:
            pass
        self._auto_map_parameters()
        return result

    def _sample_record(self):
        self.ensure_one()
        if not self.model_name or self.model_name not in self.env:
            return self.env[self.model_name].browse() if self.model_name else False
        Model = self.env[self.model_name].sudo()
        records = Model.search([], order="write_date desc, id desc", limit=50)
        for record in records:
            try:
                if self._condition_matches(record):
                    return record
            except Exception:
                continue
        return records[:1]

    def _render_preview(self, record):
        body = self.template_body or ""
        values = {}
        for line in self.parameter_ids.sorted("sequence"):
            if line.param_name:
                values[line.param_name] = self._parameter_value(record, line)
        rendered = body
        for name, value in values.items():
            rendered = re.sub(
                r"{{\s*" + re.escape(str(name)) + r"\s*}}",
                str(value or "—"),
                rendered,
            )
        if not rendered:
            rendered = _("Template «%s» Ready. Template text is not available from WATI For text preview.", self.template_name)
        return rendered

    def action_preview_latest_record(self):
        self.ensure_one()
        self._validate_step("trigger")
        if not self.template_name:
            raise UserError(_("Choose a template WATI First."))
        record = self._sample_record()
        if not record:
            raise UserError(_("There are no logs in the selected application to use for previewing."))
        self.write({
            "preview_text": self._render_preview(record),
            "preview_record_name": record.display_name or str(record.id),
        })
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("Preview has been updated"),
                "message": _("We used the log: %s", record.display_name),
                "type": "success",
                "sticky": False,
                "next": {"type": "ir.actions.client", "tag": "soft_reload"},
            },
        }

    def action_send_test(self):
        self.ensure_one()
        phone = self._normalize_phone(self.test_phone)
        if not phone:
            raise UserError(_("Write an integer test number first."))
        self._validate_activation()
        record = self._sample_record()
        if not record:
            raise UserError(_("There are no suitable records to use for testing."))
        custom_params = [
            {"name": line.param_name, "value": self._parameter_value(record, line)}
            for line in self.parameter_ids.sorted("sequence") if line.param_name
        ]
        success = self.with_context(wati_test=True)._send_template(record, phone, custom_params)
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("Submit a test"),
                "message": _("The test message has been sent to %s", phone) if success else _("Test transmission failed; Review the automation log."),
                "type": "success" if success else "danger",
                "sticky": not success,
            },
        }

    def _log_values(self, record, status, phone="", error_message="", response_excerpt=""):
        values = super()._log_values(
            record,
            status,
            phone=phone,
            error_message=error_message,
            response_excerpt=response_excerpt,
        )
        values["is_test"] = bool(self.env.context.get("wati_test"))
        return values

    @api.model
    def _upgrade_automation_ux(self):
        existing = self.sudo().search([("active", "=", True)])
        if existing:
            existing.write({"setup_step": "review"})
        return True


class WatiAutomationParameterUX(models.Model):
    _inherit = "wati.automation.parameter"

    mapping_summary = fields.Char(string="Linking", compute="_compute_mapping_summary")

    @api.depends("source_type", "source_field_id", "source_path", "static_value")
    def _compute_mapping_summary(self):
        for line in self:
            if line.source_type == "record_id":
                line.mapping_summary = "✅ Registration number"
            elif line.source_type == "record_name":
                line.mapping_summary = "✅ Record name"
            elif line.source_type == "static":
                line.mapping_summary = "✅ Fixed" if (line.static_value or "").strip() else "⚠️ Enter a value"
            elif line.source_field_id:
                line.mapping_summary = "✅ " + (line.source_field_id.field_description or line.source_field_id.name)
            elif (line.source_path or "").strip():
                line.mapping_summary = "✅ " + line.source_path
            else:
                line.mapping_summary = "⚠️ Needs connection"


class WatiAutomationLogUX(models.Model):
    _inherit = "wati.automation.log"

    is_test = fields.Boolean(string="Demo", default=False, readonly=True, index=True)


class WatiAutomationValueChoice(models.TransientModel):
    _name = "wati.automation.value.choice"
    _description = "WATI Automation Target Value Choice"
    _order = "label, id"

    rule_id = fields.Many2one("wati.automation.rule", required=True, ondelete="cascade")
    label = fields.Char(string="Value", required=True)
    value = fields.Char(string="Technical value", required=True)

    def action_select(self):
        self.ensure_one()
        self.rule_id.write({"target_value": self.label})
        return {
            "type": "ir.actions.act_window",
            "name": self.rule_id.name,
            "res_model": "wati.automation.rule",
            "res_id": self.rule_id.id,
            "view_mode": "form",
            "target": "current",
        }


class WatiAutomationTemplateChoice(models.TransientModel):
    _name = "wati.automation.template.choice"
    _description = "WATI Automation Template Choice"
    _order = "name, id"

    rule_id = fields.Many2one("wati.automation.rule", required=True, ondelete="cascade")
    name = fields.Char(string="Template", required=True)
    status = fields.Char(string="Status")
    category = fields.Char(string="Category")
    body = fields.Text(string="Preview")

    def action_select(self):
        self.ensure_one()
        rule = self.rule_id
        rule.write({"template_name": self.name, "template_body": self.body or False})
        rule.action_fetch_template_params()
        return {
            "type": "ir.actions.act_window",
            "name": rule.name,
            "res_model": "wati.automation.rule",
            "res_id": rule.id,
            "view_mode": "form",
            "target": "current",
        }
